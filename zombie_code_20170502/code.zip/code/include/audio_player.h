#ifndef AUDIO_PLAYER_H
#define AUDIO_PLAYER_H

void init_player(void);
int play_file(char* filename, int volume);
void stopAudio(void);

#endif
