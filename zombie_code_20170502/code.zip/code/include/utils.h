#ifndef UTILS_H
#define UTILS_H

#include <sys/time.h>   //struct timeval

long time_diff(struct timeval end , struct timeval start);

#endif
