#ifndef PROXIMITY_H
#define PROXIMITY_H

void init_prox(void);
double getInDistance (void);
double getCmDistance (void);
void stopPulse (void);

#endif